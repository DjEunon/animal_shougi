def next_board(board,turn):
        pass

def board_comparison(board1,board2):
    if board1==board2:
        return True    
    else:
        return False    
